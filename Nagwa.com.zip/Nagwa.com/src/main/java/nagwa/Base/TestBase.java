package nagwa.Base;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class TestBase {
	
public static WebDriver driver;

	
	@BeforeSuite
	public void startdriver() throws IOException {
		 System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
		 driver= new ChromeDriver();
		 	 

}

	 @AfterSuite
	public void quitedriver() {
		driver.quit();
	}
}
