package nagwa.Pages;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.Keys;

public class Homepage {

	WebDriver driver;
	WebDriverWait wait; 
	
	
	// webelement locators
   By lang_list = By.xpath("//div[@class='lang-list']//ul//li"); // xpath locator for lang_list
   By search_btn= By.xpath("//button[@type='button']//i[@class='f-icon search-icon']");	// locator search button
   By search_input= By.xpath("//input[@id='txt_search_query']"); // locator search input
   By search_result=By.xpath("//h1");
   By search_query=By.id("txt_query");
   By second_lesson= By.xpath("//div[@class='results']/ul[@class='list']//li[2]//a"); // xpath locator for  2nd lesson in the search results
 
	//Constructor
		public Homepage(WebDriver driver) {
			this.driver = driver;
			 wait = new WebDriverWait(driver, 60);
			
			}
			
		// method search for provided text by test Data sheet
		public void search(String search) throws InterruptedException {
			 wait.until(ExpectedConditions.visibilityOfElementLocated(search_btn));
			 WebElement searchBTN = driver.findElement(search_btn);
			 searchBTN.click();
			 
			 wait.until(ExpectedConditions.visibilityOfElementLocated(search_input));
			 WebElement search_INPUT = driver.findElement(search_input);
			 search_INPUT.sendKeys(search);
			 
			 search_INPUT.sendKeys(Keys.ENTER);
		
		}
		
	// method to validate that search result displayed and query result value provide the search input and retun true 
	public boolean validate_search_result(String search) {
		 boolean x = false;
		 wait.until(ExpectedConditions.visibilityOfElementLocated(search_result));
		WebElement search_result_element = driver.findElement(search_result);
		 boolean displayed = search_result_element.isDisplayed(); // check if search result displayed
		
		 wait.until(ExpectedConditions.visibilityOfElementLocated(search_query));
		WebElement search_query_element = driver.findElement(search_query);
		String Query_text =search_query_element.getAttribute("value"); // get the value of element 'search_query'
		if (Query_text.contains(search) && displayed == true) 
		{
			x= true;
					
		}
		return x;
	}	
		
	// method to select 2nd lesson in the search results to open its home page
	public void select_second_lesson() {
		 wait.until(ExpectedConditions.visibilityOfElementLocated(second_lesson));
			WebElement second_lesson_url = driver.findElement(second_lesson);
			second_lesson_url.click();
	}
}
