package nagwa.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LessonsPage {
	WebDriver driver;
	WebDriverWait wait; 
	
	// webelement locators
	   By lesson_menu = By.xpath("//div[@class='components']//ul//li[2]//a"); // xpath locator for lesson worksheet
	   By questions_list= By.xpath("//div[@class='question-number']"); // xpath locator to get all element with class question-number in list
	
	   //Constructor
		public LessonsPage(WebDriver driver) {
			this.driver = driver;
			 wait = new WebDriverWait(driver, 60);
			
			}
		
		// method to click on lesson worksheet link
		public void open_worksheet() {
			 wait.until(ExpectedConditions.visibilityOfElementLocated(lesson_menu));
				WebElement lesson_worksheet_elem = driver.findElement(lesson_menu);
				lesson_worksheet_elem.click();
		}
		
		// method to count questions on lessons page
		public void count_quetions() {
			 wait.until(ExpectedConditions.visibilityOfElementLocated(questions_list));
		        List <WebElement> questions_list_ = driver.findElements(questions_list); // webelement for questions list
		      int count =  questions_list_.size();
				
		      System.out.println("Number of Questions in Lesson worksheet is " + count);
		      
		         }
			
		}


