package nagwa.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LanguagesPage {
	
	WebDriver driver;
	WebDriverWait wait; 
	
	// webelement locators
	   By lang_list = By.xpath("//div[@class='lang-list']//ul//li"); // xpath locator for lang_list

	 //Constructor
	 		public LanguagesPage(WebDriver driver) {
	 			this.driver = driver;
	 			 wait = new WebDriverWait(driver, 60);
	 			
	 			}
	   
	// Method Navigate To URL provided in testData sheet	
			public void navigate(String Url) {	
				driver.navigate().to(Url);
				driver.manage().window().maximize();
							
					}
			
			// Selected_language method click on language provided by testData sheet		
			public void selected_language(String language) throws InterruptedException {
			
				 wait.until(ExpectedConditions.visibilityOfElementLocated(lang_list));
		        List <WebElement> lang_list_ = driver.findElements(lang_list); // webelement for language list
				
				 for(int i=1; i <= lang_list_.size(); i++) // loop for ALL languages in list
		         {
				 			
				 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='lang-list']//ul//li["+i+"]//a")));
					 WebElement lang = driver.findElement(By.xpath("//div[@class='lang-list']//ul//li["+i+"]//a"));
				     	String lang_name_= lang.getText(); // get text of each element in list
						if (lang_name_.contains(language)) // if element list text equel language in test Data sheet click on it
						{
						lang.click();
						break;
						}
	               }		
				
			}
}
