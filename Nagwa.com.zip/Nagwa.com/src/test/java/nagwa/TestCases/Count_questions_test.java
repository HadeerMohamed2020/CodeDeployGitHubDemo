package nagwa.TestCases;

import java.io.IOException;

import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import nagwa.Base.TestBase;
import nagwa.Pages.Homepage;
import nagwa.Pages.LanguagesPage;
import nagwa.Pages.LessonsPage;
import nagwa.testdata.TestData;

public class Count_questions_test extends TestBase {
	LanguagesPage Languages_obj;
	Homepage Homepages_obj;
	LessonsPage LessonsPage_obj;
	
	 @DataProvider(name = "nagwa_search_test")
	   	public Object[][] checkcurrency() throws InvalidFormatException, IOException,org.apache.poi.openxml4j.exceptions.InvalidFormatException { 
	   		Object[][] data= TestData.fetchData("./TestData/TestData.xlsx", "Nagwa_Serach_Test");
	   	return data;
	   	}
	 @Test (priority = 1, dataProvider="nagwa_search_test")
	 public void testcase(String url,String language ,String search) throws InterruptedException {
		 
		 Homepages_obj= new Homepage(driver); // object from Homepage
		 Languages_obj= new LanguagesPage(driver); // object from LanguagesPage
		 LessonsPage_obj= new LessonsPage(driver); // object from LessonsPage
		 
		 Languages_obj.navigate(url); // call function navigate
	     Languages_obj.selected_language(language); // call function selected_language
		 
		 Homepages_obj.search(search); // call function search
		 Homepages_obj.select_second_lesson(); // call function select_second_lesson
		 
		 LessonsPage_obj.open_worksheet(); // call function open_worksheet
		 LessonsPage_obj.count_quetions(); // methoud count questions	 
		 
	 }
}
