package nagwa.TestCases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import nagwa.Pages.Homepage;
import nagwa.Pages.LanguagesPage;
import nagwa.testdata.TestData;
import nagwa.Base.TestBase;

public class Validate_search_results extends TestBase{
	
	LanguagesPage Languages_obj;
	Homepage Homepages_obj;
	
	
	 @DataProvider(name = "nagwa_search_test")
	   	public Object[][] checkcurrency() throws InvalidFormatException, IOException,org.apache.poi.openxml4j.exceptions.InvalidFormatException { 
	   		Object[][] data= TestData.fetchData("./TestData/TestData.xlsx", "Nagwa_Serach_Test");
	   	return data;
	   	}
	 
	 // test case to validate that list with all lessons in Nagwa that match 'addition' will appear.
	 @Test (priority = 1, dataProvider="nagwa_search_test")
	 public void Validate_Nagwa_search(String url,String language ,String search) throws InterruptedException {	
		 boolean expected =true; 
		 Homepages_obj= new Homepage(driver); // object from Homepage
		 Languages_obj= new LanguagesPage(driver); // object from LanguagesPage
		 
		 Languages_obj.navigate(url); // call function navigate
	     Languages_obj.selected_language(language); // call function selected_language
		 
		 Homepages_obj.search(search); // call function search
	         boolean x = Homepages_obj.validate_search_result(search);
	    
	         assertEquals(x, expected); // Assert equal if search results displayed with addition 
		}

}
